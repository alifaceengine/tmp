#ifndef IMAGEANALYSIS_DILILI_H
#define IMAGEANALYSIS_DILILI_H
#include <utility>
using namespace std;

extern bool PROCESS_SYNC;
extern float SMOKE_THRE;
extern float PHONE_THRE;
extern float PLAY_THRE;
extern float DRINK_THRE;
extern bool IS_WINDOW;

extern "C"
{


    typedef const void* FUNC_CALLBACK_HANDLE;
    typedef const void* CONTEXT_PTR;
    namespace dilililabs
    {

    enum TaskTypeHXDT {
        TASK_UNIFORM = 0,
        TASK_BADGE = 1,
        TASK_TABLECARD = 2,
        TASK_PEOPLE_INOUT = 3,
        TASK_IMAGE_QUALITY = 4,
        TASK_PEOPLE_EXIST = 5,
        TASK_ABNORMAL_BEHAVIORS = 7,
        TASK_PEOPLE_COUNTING = 8,
        TASK_GAVELING = 9,
        TASK_ACCESSORY = 10,
    };

        enum UniformType {
            ROBE = 0,
            UNKNOWN_CLOTH=1,
            SUMMER_CLOTH = 2,
            NEW_SUMMER_CLOTH = 3,
            UNIFORM = 4,
            CASUAL_CLOTH = 5,
        };

        enum BehaviorType {
            HEAD_DOWN = 1,
            PHONE = 2,
            DRINK_WATER = 3,
            SMOKE = 4,
            PLAY_PHONE = 5,
            FALL_DOWN = 6
        };

        enum AccessoryType {
            UNKNOWN = 0,
            GLASS = 1,
            SUN_GLASS = 2,
            WEAR_HAT = 3,
            LONG_HAIR = 4
        };

    //How to:
    //
    //For each video stream,
    //CreateInstance(strm_id) -> SetTaskConfigPath(...) -> SetTaskCB(...) -> AddTask(...) -> [TransImage(...), loop n times]
    //
    //Note that, 'TransImage' will make a deep-copy of each input image first, and then
    //related tasks will be added for the current image implicitly. The above 'AddTask'
    //only defines the ROI regions and their relationships with tasks to be added.
    //You can delete one task with 'DelTask' by passing in the stream_id, rect_id and task_type,
    //or shutdown all these detections by 'DestroyInstance(strm_id)', or suspend all these
    //detections by temporarily stopping transferring new image with 'TransImage(...)'.

    bool CreateInstance(const char* stream_id);
    bool CreateInstance_2(const char* stream_id);

    //task_type: 0:cloth 1:badge 2:card 3:inout 4:quality 5:people-exist 6:tie 7:abnormal-behaviors(smoking, drinking, lookingdown, phoning)
    //           8. people counting 9: normal-behavior(gaveling, separate id for each normal behavior)
    bool AddTask(const char* stream_id,
                 const char* rect_id,
                 const int task_type,
                 const size_t roi_x,
                 const size_t roi_y,
                 const size_t roi_width,
                 const size_t roi_height);

    bool DelTask(const char* stream_id,
                 const char* rect_id,
                 const int task_type);

    bool SetTaskCB(const char* stream_id,
                   const int task_type,
                   FUNC_CALLBACK_HANDLE func_callback,
                   CONTEXT_PTR context);

    bool TransImage(const char* stream_id,
                    const int image_id,
                    const unsigned char* image_data,
                    const size_t image_width,
                    const size_t image_height);

    bool DestroyInstance(const char* stream_id);

    bool SetTaskConfigPath(const char* stream_id,
                           const char* absolute_config_path);


    // for connection status
    struct statusParam{                // parameters for status call back, for now we only need the time interval, but maybe more in the future
        int time_interval;             // time interval between each report
    };

    bool SetStatusCB(const char* stream_id,                // stream id
               const statusParam param,                    // param for status call back
               FUNC_CALLBACK_HANDLE status_callback,       // Function handler for call back funtion
               CONTEXT_PTR context);                       // context
    }

}


#endif // IMAGEANALYSIS_H