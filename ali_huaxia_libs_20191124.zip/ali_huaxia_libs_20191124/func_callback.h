#ifndef FUNC_CALLBACK_H
#define FUNC_CALLBACK_H

//#include "imageanalysis_dilili.h"
#include <stdint.h>


/****************************************************************
///
/// \brief TieCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：领带检测，更多配置信息参考task_config.json
/// \param ret: 领带检测任务返回的结果. (0->无领带; 1->有领带; -1->无法预测)
/// \param roi_w: ROI区域的宽度.
/// \param roi_h: ROI区域的高度.
/// \param encoded_roi_data: 编码后的ROI数据，可以通过DecodeRoiImage方法得到解码后的ROI数据，默认只支持RGB流
/// 即，ROI数据的大小为roi_w * row_h * 3。
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
static int  TieCallBackFunc(const char* stream_id, const int image_id,
                              const char* rect_id, const int task_type,
                              const int ret,
                              const size_t roi_w, const size_t roi_h, const void* encoded_roi_data,
                              const void* context);
****************************************************************/


///
/// \brief InOutCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：进入离开检测，更多配置信息参考task_config.json
/// \param rets: 进入离开检测任务返回的结果，数组大小为5，其中，前4项代表活动人物的位置（x, y, w, h）（目前暂时不支持此功能，会填入0，0，-1，-1，二期实现后完善），
/// 第5项代表进入（1）、离开事件（-1）以及未检测到活动事件（0）（目前暂时不支持，会填入人数变化，如少两人为-2，多一人为1，二期实现后完善）。
/// \param ret_size: 结果集大小，固定值(5)
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*InOutCallBackFuncType)(const char* stream_id, const int image_id,
                      const char* rect_id, const int task_type,
                      const int* rets, const int ret_size,
                      const size_t width, const size_t height,
                      const uint8_t* img,
                      const void* context);
int InOutCallBackFunc(const char* stream_id, const int image_id,
                      const char* rect_id, const int task_type,
                      const int* rets, const int ret_size,
                      const size_t width, const size_t height,
                      const uint8_t* img,
                      const void* context);


///
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：原/被告区的有人无人检测
/// \param ret: 原/被告区的有人无人检测任务返回的结果. (0->无人; 1->有人)
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///

typedef int (*PeopleExistCallBackFuncType)(const char* stream_id, const int image_id,
                            const char* rect_id, const int task_type,
                            const int ret,
                            const size_t width, const size_t height,
                            const uint8_t* img,
                            const void* context);
int PeopleExistCallBackFunc(const char* stream_id, const int image_id,
                            const char* rect_id, const int task_type,
                            const int ret,
                            const size_t width, const size_t height,
                            const uint8_t* img,
                            const void* context);
							
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：行为检测
/// \param rets: 行为检测任务返回的结果，返回结果二维数组，每一个数组代表单个人的行为检测结果，检测结果是长度为5的数组，其中，前4项代表人物的位置（x, y, w, h），
/// 第五项代表行为检测结果(0->低头; 1->打电话; 2->喝水; 3->抽烟； 4->敲法槌)
/// \param rets_size: 检测结果数量.
/// \param ret_size: 单个检测结果，固定大小为5.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///

typedef int (*BehaviorCallBackFuncType)(const char* stream_id, const int image_id,
                         const char* rect_id, const int task_type,
                         const int** rets, const int rets_size, const int ret_size,
                         const size_t width, const size_t height,
                         const uint8_t* img,
                         const void* context);

int BehaviorCallBackFunc(const char* stream_id, const int image_id,
                         const char* rect_id, const int task_type,
                         const int** rets, const int rets_size, const int ret_size,
                         const size_t width, const size_t height,
                         const uint8_t* img,
                         const void* context);

/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：人数检测
/// \param rets: 人数检测任务返回的结果，返回结果二维数组，每一个数组代表一个人的检测结果，单个检测结果大小为4，其中，前4项代表人物的位置（x, y, w, h），
/// \param rets_size: 人数检测结果，同时也为rets数组大小.
/// \param ret_size: 单个检测结果，固定大小为4.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*PeopleCountingCallBackFuncType)(const char* stream_id, const int image_id,
                               const char* rect_id, const int task_type,
                               const int** rets, const int rets_size, const int ret_size,
                               const size_t width, const size_t height,
                               const uint8_t* img,
                               const void* context);

int PeopleCountingCallBackFunc(const char* stream_id, const int image_id,
                               const char* rect_id, const int task_type,
                               const int** rets, const int rets_size, const int ret_size,
                               const size_t width, const size_t height,
                               const uint8_t* img,
                               const void* context);

///
/// \brief UniformCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：制服检测
/// \param rets: 制服检测任务返回的结果，返回结果二维数组，每一个数组代表单个人的制服检测结果，检测结果是长度为5的数组，其中，前4项代表人物的位置（x, y, w, h），
/// 第五项代表制服检测结果(0->法袍; 1->无法预测; 2->夏装; 3->新夏装; 4->制服)
/// \param rets_size: 检测结果数量.
/// \param ret_size: 单个检测结果，固定大小为5.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*UniformCallBackFuncType)(const char* stream_id, const int image_id,
                      const char* rect_id, const int task_type,
                      const int** rets, const int rets_size, const int ret_size,
                      const size_t width, const size_t height,
                      const uint8_t* img,
                      const void* context);
int UniformCallBackFunc(const char* stream_id, const int image_id,
                      const char* rect_id, const int task_type,
                      const int** rets, const int rets_size, const int ret_size,
                      const size_t width, const size_t height,
                      const uint8_t* img,
                      const void* context);

///
/// \brief BadgeCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：法徽检测
/// \param rets: 法徽检测任务返回的结果，返回结果二维数组，每一个数组代表单个人的法徽检测结果，检测结果是长度为5的数组，其中，前4项代表人物的位置（x, y, w, h），
/// 第五项代表法徽检测结果(0->无法徽; 1->有法徽; -1->无法预测)
/// \param rets_size: 检测结果数量.
/// \param ret_size: 单个检测结果，固定大小为5.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*BadgeCallBackFuncType)(const char* stream_id, const int image_id,
                     const char* rect_id, const int task_type,
                     const int** rets, const int rets_size, const int ret_size,
                     const size_t width, const size_t height,
                     const uint8_t* img,
                     const void* context);
int BadgeCallBackFunc(const char* stream_id, const int image_id,
                     const char* rect_id, const int task_type,
                     const int** rets, const int rets_size, const int ret_size,
                     const size_t width, const size_t height,
                     const uint8_t* img,
                     const void* context);

///
/// \brief EyewearCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：眼镜检测
/// \param rets: 眼镜检测任务返回的结果，返回结果二维数组，每一个数组代表单个人的眼镜检测结果，检测结果是长度为6的数组，其中，前4项代表人脸的位置（x, y, w, h），
/// 第5项代表眼镜检测结果(0->无眼镜; 1->普通眼镜; 2->墨镜)，第6项代表帽子检测结果(0->无帽子; 1->有帽子)。
/// \param rets_size: 检测结果数量.
/// \param ret_size: 单个检测结果，固定大小为5.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*AccessoryCallBackFuncType)(const char* stream_id, const int image_id,
                     const char* rect_id, const int task_type,
                     const int** rets, const int rets_size, const int ret_size,
                     const size_t width, const size_t height,
                     const uint8_t* img,
                     const void* context);
int AccessoryCallBackFunc(const char* stream_id, const int image_id,
                     const char* rect_id, const int task_type,
                     const int** rets, const int rets_size, const int ret_size,
                     const size_t width, const size_t height,
                     const uint8_t* img,
                     const void* context);

///
/// \brief TableCardCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：桌牌检测
/// \param rets: 桌牌检测任务返回的结果，返回结果二维数组，每一个数组代表单个桌牌检测结果，检测结果是长度为4的数组，每一组代表桌牌的位置（x, y, w, h）
/// \param rets_size: 检测结果数量.
/// \param ret_size: 单个检测结果，固定大小为4.
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*TableCardCallBackFuncType)(const char* stream_id, const int image_id,
                          const char* rect_id, const int task_type,
                          const int** rets, const int rets_size, const int ret_size,
                          const size_t width, const size_t height,
                          const uint8_t* img,
                          const void* context);
int TableCardCallBackFunc(const char* stream_id, const int image_id,
                          const char* rect_id, const int task_type,
                          const int** rets, const int rets_size, const int ret_size,
                          const size_t width, const size_t height,
                          const uint8_t* img,
                          const void* context);


///
/// \brief QualityCallBackFunc
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param rect_id: 当前流的ROI区域的ID（uuid）
/// \param task_type: 任务类型：质量检测
/// \param rets: 质量检测任务返回的结果（每项均大于或等于0），数组大小为5。第1项为清晰值，与图像失焦、丢失相关，值越大表示图像越清晰，值越小表示越模糊或者 说失焦越严重，接近于0时表示出现图像丢失问题；第2，3项为亮度，暗度值，亮值越大表示图像越亮，反之则越暗，暗度值相反；第4项为偏色值，值越大表示偏色现象越严重，反之表示图像无明显偏色。
///              第5项为无信号，为bool值，第6项为画面冻结，为bool值。
/// \param ret_size: 结果集大小，固定值(6)
/// \param width: 截图的宽度.
/// \param height: 截图的高度.
/// \param img: 截图数据，opencv BGR格式
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*QualityCallBackFuncType)(const char* stream_id, const int image_id,
                        const char* rect_id, const int task_type,
                        const float* rets, const int ret_size,
                        const size_t roi_w, const size_t roi_h,
                        const void* encoded_roi_data,
                        const void* context);

int QualityCallBackFunc(const char* stream_id, const int image_id,
                        const char* rect_id, const int task_type,
                        const float* rets, const int ret_size,
                        const size_t roi_w, const size_t roi_h,
                        const void* encoded_roi_data,
                        const void* context);

// for connection status
/// \param stream_id: 流标识（uuid）
/// \param image_id: 当前流的图像ID
/// \param status_code: 服务连接状态 （0：在线 1：断线正在重连）
/// \param context: 当前上下文
/// \return 返回当前回调函数的状态码，0为正常.
///
typedef int (*StatusCallBackFuncType)(const char* stream_id,              // stream id
                       const char* rect_id,                // rect id, for now, we just need to set it to "NA"
                       const int status_code,              // status code
                       const void* context);

int StatusCallBackFunc(const char* stream_id,              // stream id
                       const char* rect_id,                // rect id, for now, we just need to set it to "NA"
                       const int status_code,              // status code
                       const void* context);

#endif // FUNC_CALLBACK_H
